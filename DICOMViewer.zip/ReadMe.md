﻿
# DICOMViewer 프로젝트
(교재 4장 예제)

포함된 기능 
- DICOM 폴더 읽기
- DICOM 태그 정보 읽기
- DICOM 그룹 분류
- 동일 그룹의 DICOM Volume 데이터 읽기
- Axial, Coronal, Sagittal 방향 슬라이스 이미지 생성
- 스크롤 바를 통한 슬라이스 탐색
- 3D Volume Rendering





